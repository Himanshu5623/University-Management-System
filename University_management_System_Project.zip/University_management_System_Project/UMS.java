import javax.swing.*;
import java.awt.*;
import java.util.*;

public class uniman {

    static class Student {
        String id, name;
        Student(String id, String name) { this.id = id; this.name = name; }
        public String toString() { return id + " - " + name; }
    }

    static class Faculty {
        String id, name;
        Faculty(String id, String name) { this.id = id; this.name = name; }
        public String toString() { return id + " - " + name; }
    }

    static class Course {
        String code, title;
        Faculty faculty;
        int capacity;
        java.util.List<Student> enrolled = new ArrayList<>();
        Queue<Student> waitingList = new LinkedList<>();

        Course(String code, String title, int capacity) {
            this.code = code;
            this.title = title;
            this.capacity = capacity;
        }

        void assignFaculty(Faculty f) { this.faculty = f; }

        boolean enroll(Student s) {
            if (enrolled.size() < capacity) {
                enrolled.add(s);
                return true;
            } else {
                waitingList.add(s);
                return false;
            }
        }

        String getDetails() {
            StringBuilder sb = new StringBuilder();
            sb.append("Course: ").append(title).append(" (").append(code).append(")\n");
            sb.append("Faculty: ").append(faculty != null ? faculty.name : "Not Assigned").append("\n\n");
            sb.append("Enrolled Students:\n");
            for (Student s : enrolled) sb.append(" • ").append(s.name).append("\n");
            sb.append("\nWaiting List:\n");
            for (Student s : waitingList) sb.append(" - ").append(s.name).append("\n");
            return sb.toString();
        }
    }

    static java.util.List<Student> students = new ArrayList<>();
    static java.util.List<Faculty> faculties = new ArrayList<>();
    static Map<String, Course> courses = new HashMap<>();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(uniman::createMainGUI);
    }

    static class RoundedButton extends JButton {
        private Color hoverBackgroundColor;
        private Color pressedBackgroundColor;

        public RoundedButton(String text) {
            super(text);
            setContentAreaFilled(false);
            setFocusPainted(false);
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.BOLD, 15));
            setBackground(Color.BLACK);
            hoverBackgroundColor = new Color(30,30,30);
            pressedBackgroundColor = new Color(60,60,60);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (getModel().isPressed()) g2.setColor(pressedBackgroundColor);
            else if (getModel().isRollover()) g2.setColor(hoverBackgroundColor);
            else g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
            FontMetrics fm = g2.getFontMetrics();
            Rectangle rect = new Rectangle(0, 0, getWidth(), getHeight());
            int x = rect.x + (rect.width - fm.stringWidth(getText())) / 2;
            int y = rect.y + (rect.height - fm.getHeight()) / 2 + fm.getAscent();
            g2.setColor(getForeground());
            g2.drawString(getText(), x, y);
            g2.dispose();
        }

        @Override
        public void setContentAreaFilled(boolean b) { }
    }

    static void createMainGUI() {
        JFrame frame = new JFrame("🎓 University Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 650);
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(new Color(230, 245, 255));

        JLabel title = new JLabel("University Management System", SwingConstants.CENTER);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(0, 102, 204));
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 30, 0));
        frame.add(title);

        RoundedButton addStudentBtn = new RoundedButton("Add Student");
        RoundedButton addFacultyBtn = new RoundedButton("Add Faculty");
        RoundedButton createCourseBtn = new RoundedButton("Create Course");
        RoundedButton assignFacultyBtn = new RoundedButton("Assign Faculty to Course");
        RoundedButton enrollStudentBtn = new RoundedButton("Enroll Student in Course");
        RoundedButton viewCourseBtn = new RoundedButton("View Course Details");
        RoundedButton exitBtn = new RoundedButton("Exit");
        exitBtn.setMaximumSize(new Dimension(200, 40));
        exitBtn.setForeground(Color.RED);

        RoundedButton[] buttons = {addStudentBtn, addFacultyBtn, createCourseBtn, assignFacultyBtn, enrollStudentBtn, viewCourseBtn, exitBtn};

        for (RoundedButton btn : buttons) {
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            if (btn != exitBtn) btn.setMaximumSize(new Dimension(300, 50));
            frame.add(Box.createRigidArea(new Dimension(0, 15)));
            frame.add(btn);
        }

        addStudentBtn.addActionListener(e -> {
            String id = JOptionPane.showInputDialog("Enter Student ID:");
            String name = JOptionPane.showInputDialog("Enter Student Name:");
            if (id != null && name != null && !id.isEmpty() && !name.isEmpty()) {
                students.add(new Student(id.trim(), name.trim()));
                JOptionPane.showMessageDialog(null, "✅ Student added successfully!");
            }
        });

        addFacultyBtn.addActionListener(e -> {
            String id = JOptionPane.showInputDialog("Enter Faculty ID:");
            String name = JOptionPane.showInputDialog("Enter Faculty Name:");
            if (id != null && name != null && !id.isEmpty() && !name.isEmpty()) {
                faculties.add(new Faculty(id.trim(), name.trim()));
                JOptionPane.showMessageDialog(null, "✅ Faculty added successfully!");
            }
        });

        createCourseBtn.addActionListener(e -> {
            String code = JOptionPane.showInputDialog("Enter Course Code:");
            String titleText = JOptionPane.showInputDialog("Enter Course Title:");
            try {
                int cap = Integer.parseInt(JOptionPane.showInputDialog("Enter Capacity:"));
                courses.put(code.trim(), new Course(code.trim(), titleText.trim(), cap));
                JOptionPane.showMessageDialog(null, "📘 Course created successfully!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "❌ Invalid input for capacity.");
            }
        });

        assignFacultyBtn.addActionListener(e -> {
            String code = JOptionPane.showInputDialog("Enter Course Code:");
            String fid = JOptionPane.showInputDialog("Enter Faculty ID:");
            Course c = courses.get(code.trim());
            Faculty f = findFaculty(fid.trim());
            if (c != null && f != null) {
                c.assignFaculty(f);
                JOptionPane.showMessageDialog(null, "👨‍🏫 Faculty assigned successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "❌ Invalid course or faculty.");
            }
        });

        enrollStudentBtn.addActionListener(e -> {
            String code = JOptionPane.showInputDialog("Enter Course Code:");
            String sid = JOptionPane.showInputDialog("Enter Student ID:");
            Course c = courses.get(code.trim());
            Student s = findStudent(sid.trim());
            if (c != null && s != null) {
                boolean enrolled = c.enroll(s);
                JOptionPane.showMessageDialog(null, enrolled ? "🎉 Student enrolled successfully!" : "⚠️ Course full — added to waiting list.");
            } else {
                JOptionPane.showMessageDialog(null, "❌ Invalid course or student.");
            }
        });

        viewCourseBtn.addActionListener(e -> {
            String code = JOptionPane.showInputDialog("Enter Course Code:");
            Course c = courses.get(code.trim());
            if (c != null) {
                JTextArea area = new JTextArea(c.getDetails());
                area.setEditable(false);
                area.setFont(new Font("Consolas", Font.PLAIN, 14));
                area.setBackground(new Color(245, 255, 250));
                JOptionPane.showMessageDialog(null, new JScrollPane(area), "📄 Course Details", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "❌ Course not found.");
            }
        });

        exitBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Confirm Exit", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) frame.dispose();
        });

        frame.setVisible(true);
    }

    static Student findStudent(String id) {
        for (Student s : students) if (s.id.equalsIgnoreCase(id)) return s;
        return null;
    }

    static Faculty findFaculty(String id) {
        for (Faculty f : faculties) if (f.id.equalsIgnoreCase(id)) return f;
        return null;
    }
}
